import serial
import time
print("start")
bluetooth = serial.Serial('COM10',115200)
print('connected')
bluetooth.flushInput()
bluetooth.write('a %d' %(100))
time.sleep(0.1)     
bluetooth.close()
print("Done")
