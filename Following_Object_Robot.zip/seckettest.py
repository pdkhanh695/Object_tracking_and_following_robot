#!/usr/bin/python3
import cv2
import httplib2
 
http = httplib2.Http()

i = 0
#print(content.decode())
while True:
    i = i+1
    print(i)
    if i<100:
        content = http.request("http://192.168.1.3/speed?speed=500")[1]
        content = http.request("http://192.168.1.3/forward")[1]
    if i>100 and i<200:
        content = http.request("http://192.168.1.3/speed?speed=1000")[1]
        content = http.request("http://192.168.1.3/forward")[1]
    k = cv2.waitKey(5) & 0xFF
    if k == 27:
        break
