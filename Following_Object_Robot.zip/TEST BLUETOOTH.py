#Author: Dinh Khanh Phan
#Day: 24/06/2018
 
# import the necessary packages
from collections import deque
import numpy as np
import argparse
import imutils
import cv2
import urllib #for reading image from URL
import os, sys
import time
import serial
bluetooth = serial.Serial('COM11',115200)
print('connected')
bluetooth.flushInput()

#---------------------------------
#Sub function PID
Kp = 0.5
Ki = 0.5
Kd = 0.01
global errorb
global derivativeb 
global previous_errorb 
global integralb 
global outputb
errorb= 0.0
derivativeb = 0.0
previous_errorb = 0.0
integralb = 0.0
outputb = 0.0
global errorg
global derivativeg 
global previous_errorg 
global integralg 
global outputg
errorg= 0.0
derivativeg = 0.0
previous_errorg = 0.0
integralg = 0.0
outputg = 0.0
global errorfw
global derivativefw
global previous_errorfw
global integralfw
global outputfw
errorg= 0.0
derivativeg = 0.0
previous_errorg = 0.0
integralg = 0.0
outputg = 0.0



def pidcontrolrotateb( error_ ):
    global errorb
    global derivativeb 
    global previous_errorb 
    global integralb 
    global outputb
    errorb=error_;
    #integralb = integralb + errorb*0.02
    derivativeb = errorb - previous_errorb
    outputb = Kp*errorb+Ki*integralb+Kd*derivativeb
    previous_errorb=errorb
    if outputb > 254:
        output = 254
    if outputb <-254:
        outputb = -254  
    return outputb
def pidcontrolrotateg( error_ ):
    global errorg
    global derivativeg 
    global previous_errorg 
    global integralg 
    global outputg
    errorg=error_;
    #integralg = integralg + errorg*0.02
    derivativeg=errorg - previous_errorg
    outputg = Kp*errorg+Ki*integralg+Kd*derivativeg
    previous_errorg=errorg
    if outputg > 254:
        outputg = 254
    if outputg <-254:
        outputg = -254  
    return outputg
def pidcontrolforward( error_ ):
    global errorfw
    global derivativefw
    global previous_errorfw 
    global integralfw
    global outputfw
    errorg=error_;
    #integralfw = integralfw + errorfw*0.02
    derivativefw=errorfw - previous_errorfw
    outputfw = Kp*errorfw+Ki*integralfw+Kd*derivativefw
    previous_errorfw=errorfw
    if outputw > 254:
        outputw = 254
    if outputw <-254:
        outputw = -254  
    return outputfw
#------------------------------------flag
flagrorateg = 0
flagrotateb = 0
flagforwardb = 0
flagforwardg = 0
flagforwardsensorg = 0
flagforwardsensorb = 0

flagholdb = 1
flagholdg = 1

#print(content.decode())
#path_to_library = os.path.join(os.path.dirname(__file__),"httplib2/python2")
#sys.path.append(path_to_library)
#import httplib2

def nothing(*arg):
        pass
# construct the argument parse and parse the arguments
ap = argparse.ArgumentParser()
ap.add_argument("-v", "--video",
    help="path to the (optional) video file")
ap.add_argument("-b", "--buffer", type=int, default=64,
    help="max buffer size")
args = vars(ap.parse_args())


cv2.namedWindow('colorTest')
HLB = 97; SLB = 100;  VLB = 47;
HUB =117; SUB = 255; VUB = 255;

HLR = 55; SLR = 39;  VLR = 9;
HUR =86; SUR = 255; VUR = 255;

#define item
flagg = 0;
flagb = 0;

posxg = 0; posyg = 0;
posxb = 0; posyb = 0;

errorx = 0;
errory = 0;

#PID CONTROL ROTATE
icol1 = (HLB, SLB, VLB, HUB, SUB, VUB)    # BLUE
icol2 = (HLR, SLR, VLR, HUR, SUR, VUR)    # RED -> GREEN 
# define the lower and upper boundaries of the colors in the HSV color space
lower = {'blue':(HLB, SLB, VLB),'green':(HLR,SLR, VLR)} #assign new item lower['blue'] = (93, 10, 0)
upper = { 'blue':(HUB,SUB,VUB),'green':(HUR,SUR,VUR)}
# define standard colors for circle around the object
colors = {'blue':(255,0,0), 'green':(0,255,0)}
# Lower range colour sliders.
cv2.createTrackbar('lowHueB', 'colorTest', icol1[0], 255, nothing)
cv2.createTrackbar('lowSatB', 'colorTest', icol1[1], 255, nothing)
cv2.createTrackbar('lowValB', 'colorTest', icol1[2], 255, nothing)
# Higher range colour sliders.
cv2.createTrackbar('highHueB', 'colorTest', icol1[3], 255, nothing)
cv2.createTrackbar('highSatB', 'colorTest', icol1[4], 255, nothing)
cv2.createTrackbar('highValB', 'colorTest', icol1[5], 255, nothing)
# Lower range colour sliders.
cv2.createTrackbar('lowHueR', 'colorTest', icol2[0], 255, nothing)
cv2.createTrackbar('lowSatR', 'colorTest', icol2[1], 255, nothing)
cv2.createTrackbar('lowValR', 'colorTest', icol2[2], 255, nothing)
# Higher range colour sliders.
cv2.createTrackbar('highHueR', 'colorTest', icol2[3], 255, nothing)
cv2.createTrackbar('highSatR', 'colorTest', icol2[4], 255, nothing)
cv2.createTrackbar('highValR', 'colorTest', icol2[5], 255, nothing)

#pts = deque(maxlen=args["buffer"])
 
# if a video path was not supplied, grab the reference
# to the webcam
if not args.get("video", False):
    camera = cv2.VideoCapture(0)
   
# otherwise, grab a reference to the video file
else:
    camera = cv2.VideoCapture(args["video"])
# keep looping
while True:
    time.sleep(0.05)
    #content = http.request("http://192.168.1.99:3000/forward")[0]
    # grab the current frame
    (grabbed, frame) = camera.read()
    # if we are viewing a video and we did not grab a frame,
    # then we have reached the end of the video
    if args.get("video") and not grabbed:
        break
    
    #IP webcam image stream
    #URL = 'http://192.168.43.1:8080/shot.jpg'
    #urllib.urlretrieve(URL, 'shot1.jpg')
    #frame = cv2.imread('shot1.jpg')
    
 
    # resize the frame, blur it, and convert it to the HSV
    # color space
    frame = imutils.resize(frame, width=600)
    #Get width and height of frame
    height, width, channel = frame.shape 
    #print('width',width,'height',height)
    # Get HSV values from the GUI sliders.
    HLB = cv2.getTrackbarPos('lowHueB', 'colorTest')
    SLB = cv2.getTrackbarPos('lowSatB', 'colorTest')
    VLB = cv2.getTrackbarPos('lowValB', 'colorTest')
    HUB = cv2.getTrackbarPos('highHueB', 'colorTest')
    SUB = cv2.getTrackbarPos('highSatB', 'colorTest')
    VUB = cv2.getTrackbarPos('highValB', 'colorTest')
    # Get HSV values from the GUI sliders.
    HLR = cv2.getTrackbarPos('lowHueR', 'colorTest')
    SLR = cv2.getTrackbarPos('lowSatR', 'colorTest')
    VLR = cv2.getTrackbarPos('lowValR', 'colorTest')
    HUR = cv2.getTrackbarPos('highHueR', 'colorTest')
    SUR = cv2.getTrackbarPos('highSatR', 'colorTest')
    VUR = cv2.getTrackbarPos('highValR', 'colorTest')
   #print ('hlb',HLB,'hub', HUB,'slb', SLB,'sub',SUB,'vlb', VLB,'vub',VUB)
   #print ('hlR',HLR,'huR', HUR,'slR', SLR,'suR',SUR,'vlR', VLR,'vuR',VUR)
    
    #lower = {'blue':(HLB, SLB, VLB),'red':(HLR,SLR, VLR)} #assign new item lower['blue'] = (93, 10, 0)
    #upper = { 'blue':(HUB,SUB,VUB),'red':(HUR,SUR,VUR)}
    lower = {'blue':(HLB, SLB, VLB),'green':(HLR,SLR, VLR)} #assign new item lower['blue'] = (93, 10, 0)
    upper = { 'blue':(HUB,SUB,VUB),'green':(HUR,SUR,VUR)}
    # Show the original image
    blurred = cv2.GaussianBlur(frame, (11, 11), 0)
    #cv2.imshow("Blur", blurred)
    hsv = cv2.cvtColor(blurred, cv2.COLOR_BGR2HSV)
    #cv2.imshow("HSV", hsv)
    #h, s, v = cv2.split(hsv)
    #cv2.imshow("H", h)
    #cv2.imshow("S", s)
    #cv2.imshow("V", v)
    #for each color in dictionary check object in frame
    for key, value in upper.items():
        # construct a mask for the color from dictionary`1, then perform
        # a series of dilations and erosions to remove any small
        # blobs left in the mask
        if key == 'blue':
                kernel = np.ones((9,9),np.uint8)
                mask = cv2.inRange(hsv, lower[key], upper[key])
                mask = cv2.morphologyEx(mask, cv2.MORPH_OPEN, kernel)
                mask = cv2.morphologyEx(mask, cv2.MORPH_CLOSE, kernel)
                cv2.imshow("Mask blue", mask)
        if key == 'green':
                kernel = np.ones((9,9),np.uint8)
                mask = cv2.inRange(hsv, lower[key], upper[key])
                mask = cv2.morphologyEx(mask, cv2.MORPH_OPEN, kernel)
                mask = cv2.morphologyEx(mask, cv2.MORPH_CLOSE, kernel)
                cv2.imshow("Mask green", mask)

        # find contours in the mask and initialize the current
        # (x, y) center of the ball
        cnts = cv2.findContours(mask.copy(), cv2.RETR_EXTERNAL,
            cv2.CHAIN_APPROX_SIMPLE)[-2]
        center = None
        # only proceed if at least one contour was found
        if len(cnts) > 0:
            # find the largest contour in the mask, then use
            # it to compute the minimum enclosing circle and
            # centroid
            c = max(cnts, key=cv2.contourArea)
            ((x, y), radius) = cv2.minEnclosingCircle(c)
            M = cv2.moments(c)
            center = (int(M["m10"] / M["m00"]), int(M["m01"] / M["m00"]))
       
            # only proceed if the radius meets a minimum size. Correct this value for your obect's size
            if radius > 0.5:
                # draw the circle and centroid on the frame,
                # then update the list of tracked points
                #print('Tam vat mau',key,'la',int(x),'va',int(y))
                #cv2.circle(frame, (int(x), int(y)), int(radius), colors[key], 2)
                #cv2.circle(frame, (int(x), int(y)), int(2), colors[key], 2)
                #Draw central line of the item 
                cv2.line(frame,(int(x) + 10,int(y)),(int(x) - 10,int(y)),(255,255,0),1)
                cv2.line(frame,(int(x),int(y) +10),(int(x),int(y) -10),(255,255,0),1)
                cv2.putText(frame,key + "item", (int(x-radius),int(y-radius)), cv2.FONT_HERSHEY_SIMPLEX, 0.6,colors[key],1)
                #print("Ban kinh =%d",radius)
                if key == 'blue':
                    #if flagforwardsensorb == 0:
                        flagforwardsensorg = 1
                        posxb = int(x);
                        posyb = int(y);
                        #print('Blue',posxb,' ',posyb)
                        flagb = 1;
                        errorb = width/2 - posxb
                        print('Error b =  %d' %errorb)
                        error_f = int(pidcontrolrotateg(errorb))
                        if errorb >25:            
                            error_f = abs(error_f)
                            #bluetooth.write("L%d#" %error_f)
                            bluetooth.write("L%d#" %75)
                            print("left blue= %d" %(error_f))
                        if errorb <-25:            
                            error_f = abs(error_f)
                            #bluetooth.write("R%d#" %error_f)
                            bluetooth.write("R%d#" %75)
                            print("right blue=%d " %(error_f))
                        if ((errorb <=25) and (errorb >=-25)):
                            print("forward blue= %d" %(75))
                            bluetooth.write("F%d#" %abs(75))
                            #content = bluetooth.write("http://192.168.43.99:3000/fc51")[1]
                            '''
                            a = int(content[10])
                            if a == 0:
                                while flagholdb:
                                    bluetooth.write("http://192.168.43.99:3000/open")[1]
                                    bluetooth.write("http://192.168.43.99:3000/speed?speed=%d" %(380))[1] 
                                    bluetooth.write("http://192.168.43.99:3000/left")[1]
                                    time.sleep(1)
                                    bluetooth.write("http://192.168.43.99:3000/left")[1]
                                    time.sleep(1)
                                    bluetooth.write("http://192.168.43.99:3000/forward")[1]
                                    time.sleep(1)
                                    bluetooth.write("http://192.168.43.99:3000/forward")[1]
                                    time.sleep(1)
                                    bluetooth.write("http://192.168.43.99:3000/forward")[1]
                                    time.sleep(1)
                                    bluetooth.write("http://192.168.43.99:3000/close")[1]
                                    time.sleep(1)
                                    bluetooth.write("http://192.168.43.99:3000/backward")[1]
                                    time.sleep(1)
                                    bluetooth.write("http://192.168.43.99:3000/backward")[1]
                                    time.sleep(1)
                                    bluetooth.write("http://192.168.43.99:3000/backward")[1]
                                    time.sleep(1)
                                    bluetooth.write("http://192.168.43.99:3000/right")[1]
                                    time.sleep(1)
                                    bluetooth.write("http://192.168.43.99:3000/right")[1]
                                    time.sleep(1)
                                    bluetooth.write("http://192.168.43.99:3000/right")[1]
                                    flagholdb = 0
                                    flagforwardsensorb = 1
                                    flagforwardsensorg = 0
                            '''
                
                if key == 'green':
                    #if flagforwardsensorg == 0:
                        flagforwardsensorb = 1
                        posxg = int(x);
                        posyg = int(y);
                        #print('Green',posxg,' ',posyg)
                        flagg = 1;
                        error_g = width/2 - posxg
                        a = pidcontrolrotateg(error_g)
                        print('Errog b =  %d' %error_g)
                        if error_g >25:
                            a = abs(a)
                            #bluetooth.write("L%d#" %a)
                            bluetooth.write("L%d#" %75)
                            print("left green= %d" %(a))
                        if error_g < -25:
                            a = abs(a)
                            #bluetooth.write("R%d#" %(abs(a)))
                            bluetooth.write("R%d#" %75)
                            print("right green= %d " %(a))
                        if (error_g <=25) and (error_g >=-25):
                            bluetooth.write("F%d#" %75)
                            print("forward green= %d" %(50))
                            #content = bluetooth.write("http://192.168.43.99:3000/fc51")[1]
                   
                            '''
                            a = int(content[10])
                            if a == 0:
                                while flagholdb:
                                    bluetooth.write("http://192.168.43.99:3000/open")[1]
                                    bluetooth.write("http://192.168.43.99:3000/speed?speed=%d" %(350))[1] 
                                    bluetooth.write("http://192.168.43.99:3000/right")[1]
                                    time.sleep(1)
                                    bluetooth.write("http://192.168.43.99:3000/right")[1]
                                    time.sleep(1)
                                    bluetooth.write("http://192.168.43.99:3000/forward")[1]
                                    time.sleep(1)
                                    bluetooth.write("http://192.168.43.99:3000/forward")[1]
                                    time.sleep(1)
                                    bluetooth.write("http://192.168.43.99:3000/forward")[1]
                                    time.sleep(1)
                                    bluetooth.write("http://192.168.43.99:3000/close")[1]
                                    time.sleep(1)
                                    bluetooth.write("http://192.168.43.99:3000/backward")[1]
                                    time.sleep(1)
                                    bluetooth.write("http://192.168.43.99:3000/backward")[1]
                                    time.sleep(1)
                                    bluetooth.write("http://192.168.43.99:3000/backward")[1]
                                    time.sleep(1)
                                    bluetooth.write("http://192.168.43.99:3000/left")[1]
                                    time.sleep(1)
                                    bluetooth.write("http://192.168.43.99:3000/left")[1]
                                    flagholdg = 0
                                    flagforwardsensorb = 0
                                    flagforwardsensorg = 1
                           '''
                        
    '''                     
    #if flagb == 1:
    #   print('Errorb',width/2 - posxb,' ',height/2 - posyb)
    #    flagb = 0
    #if flagg ==1:
    #    print('Errorg',width/2 - posxg,' ',height/2 - posyg)
    #    flagg = 0
    
    if flagb == 1:
        print('Error item blue x',width/2 - posxb)
        if (width/2 - posxb) > 30:
            content = http.request("http://192.168.1.99/left")[1]
            content = http.request("http://192.168.1.99/speed?speed=500")[1]
        if (width/2 - posxb) < -30:
            content = http.request("http://192.168.1.99/right")[1]
            content = http.request("http://192.168.1.99/speed?speed=500")[1]
        flagb = 0
    if flagg ==1:
        print('Error item green y',width/2 - posxg)
        if (width/2 - posxg) > 30:
            content = http.request("http://192.168.1.99/left")[1]
            content = http.request("http://192.168.1.99/speed?speed=500")[1]
        if (width/2 - posxg) < -30:
            content = http.request("http://192.168.1.99/right")[1]
            content = http.request("http://192.168.1.99/speed?speed=500")[1]
        flagg = 0
    '''
    #Draw central line of the frame 
    cv2.line(frame,(width/2,height/2-300),(width/2,height/2 + 300),(255,255,0),1)
    cv2.line(frame,(width/2-300,height/2),(width/2+300,height/2),(255,255,0),1)
    #time.sleep(0.005)
    # show the frame to our screen
    cv2.imshow("Frame", frame)

    # if the esc key is pressed, stop the loop
    k = cv2.waitKey(5) & 0xFF
    if k == 27:
        break
# cleanup the camera and close any open windows
bluetooth.write("A%d#" %65)
camera.release()
cv2.destroyAllWindows()
time.sleep(0.1)     
bluetooth.close()
print("Done")

