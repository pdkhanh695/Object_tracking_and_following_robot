#Author: Dinh Khanh Phan
#Day: 24/06/2018
 
# import the necessary packages
from collections import deque
import numpy as np
import argparse
import imutils
import cv2
import urllib #for reading image from URL

def nothing(*arg):
        pass
# construct the argument parse and parse the arguments
ap = argparse.ArgumentParser()
ap.add_argument("-v", "--video",
    help="path to the (optional) video file")
ap.add_argument("-b", "--buffer", type=int, default=64,
    help="max buffer size")
args = vars(ap.parse_args())


cv2.namedWindow('colorTest')
HLB = 97; SLB = 100;  VLB = 117;
HUB =117; SUB = 255; VUB = 255;

HLR = 166; SLR = 84;  VLR = 141;
HUR =186; SUR = 255; VUR = 255;

icol1 = (HLB, SLB, VLB, HUB, SUB, VUB)    # BLUE
icol2 = (HLR, SLR, VLR, HUR, SUR, VUR)    # RED
# define the lower and upper boundaries of the colors in the HSV color space
lower = {'blue':(HLB, SLB, VLB),'red':(HLR,SLR, VLR)} #assign new item lower['blue'] = (93, 10, 0)
upper = { 'blue':(HUB,SUB,VUB),'red':(HUR,SUR,VUR)}
# define standard colors for circle around the object
colors = {'blue':(255,0,0), 'red':(0,0,255)}
# Lower range colour sliders.
cv2.createTrackbar('lowHueB', 'colorTest', icol1[0], 255, nothing)
cv2.createTrackbar('lowSatB', 'colorTest', icol1[1], 255, nothing)
cv2.createTrackbar('lowValB', 'colorTest', icol1[2], 255, nothing)
# Higher range colour sliders.
cv2.createTrackbar('highHueB', 'colorTest', icol1[3], 255, nothing)
cv2.createTrackbar('highSatB', 'colorTest', icol1[4], 255, nothing)
cv2.createTrackbar('highValB', 'colorTest', icol1[5], 255, nothing)
 
# Lower range colour sliders.
cv2.createTrackbar('lowHueR', 'colorTest', icol2[0], 255, nothing)
cv2.createTrackbar('lowSatR', 'colorTest', icol2[1], 255, nothing)
cv2.createTrackbar('lowValR', 'colorTest', icol2[2], 255, nothing)
# Higher range colour sliders.
cv2.createTrackbar('highHueR', 'colorTest', icol2[3], 255, nothing)
cv2.createTrackbar('highSatR', 'colorTest', icol2[4], 255, nothing)
cv2.createTrackbar('highValR', 'colorTest', icol2[5], 255, nothing)

 
#pts = deque(maxlen=args["buffer"])
 
# if a video path was not supplied, grab the reference
# to the webcam
if not args.get("video", False):
    camera = cv2.VideoCapture(0)
   
# otherwise, grab a reference to the video file
else:
    camera = cv2.VideoCapture(args["video"])
# keep looping
while True:
    # grab the current frame
    (grabbed, frame) = camera.read()
    # if we are viewing a video and we did not grab a frame,
    # then we have reached the end of the video
    if args.get("video") and not grabbed:
        break
 
    #IP webcam image stream
    #URL = 'http://10.254.254.102:8080/shot.jpg'
    #urllib.urlretrieve(URL, 'shot1.jpg')
    #frame = cv2.imread('shot1.jpg')
 
 
    # resize the frame, blur it, and convert it to the HSV
    # color space
    frame = imutils.resize(frame, width=600)
    #Get width and height of frame
    height, width, channel = frame.shape 
    #print('width',width,'height',height)
    # Get HSV values from the GUI sliders.
    HLB = cv2.getTrackbarPos('lowHueB', 'colorTest')
    SLB = cv2.getTrackbarPos('lowSatB', 'colorTest')
    VLB = cv2.getTrackbarPos('lowValB', 'colorTest')
    HUB = cv2.getTrackbarPos('highHueB', 'colorTest')
    SUB = cv2.getTrackbarPos('highSatB', 'colorTest')
    VUB = cv2.getTrackbarPos('highValB', 'colorTest')
    # Get HSV values from the GUI sliders.
    HLO = cv2.getTrackbarPos('lowHueR', 'colorTest')
    SLO = cv2.getTrackbarPos('lowSatR', 'colorTest')
    VLO = cv2.getTrackbarPos('lowValR', 'colorTest')
    HUO = cv2.getTrackbarPos('highHueR', 'colorTest')
    SUO = cv2.getTrackbarPos('highSatR', 'colorTest')
    VUO = cv2.getTrackbarPos('highValR', 'colorTest')
    #print ('hlb',HLB,'hub', HUB,'slb', SLB,'sub',SUB,'vlb', VLB,'vub',VUB)
    #print ('hlo',HLO,'huo', HUO,'slo', SLO,'suo',SUO,'vlo', VLO,'vuo',VUO)
    
    lower = {'blue':(HLB, SLB, VLB),'red':(HLR,SLR, VLR)} #assign new item lower['blue'] = (93, 10, 0)
    upper = { 'blue':(HUB,SUB,VUB),'red':(HUR,SUR,VUR)}
    # Show the original image
    blurred = cv2.GaussianBlur(frame, (11, 11), 0)
    # cv2.imshow("Blur", blurred)
    hsv = cv2.cvtColor(blurred, cv2.COLOR_BGR2HSV)
    #cv2.imshow("HSV", hsv)
    #h, s, v = cv2.split(hsv)
    #cv2.imshow("H", h)
    #cv2.imshow("S", s)
    #cv2.imshow("V", v)
    #for each color in dictionary check object in frame
    for key, value in upper.items():
        # construct a mask for the color from dictionary`1, then perform
        # a series of dilations and erosions to remove any small
        # blobs left in the mask
        kernel = np.ones((9,9),np.uint8)
        mask = cv2.inRange(hsv, lower[key], upper[key])
        #cv2.imshow("Mask", mask)
        mask = cv2.morphologyEx(mask, cv2.MORPH_OPEN, kernel)
        mask = cv2.morphologyEx(mask, cv2.MORPH_CLOSE, kernel)
        
        # find contours in the mask and initialize the current
        # (x, y) center of the ball
        cnts = cv2.findContours(mask.copy(), cv2.RETR_EXTERNAL,
            cv2.CHAIN_APPROX_SIMPLE)[-2]
        center = None
       
        # only proceed if at least one contour was found
        if len(cnts) > 0:
            # find the largest contour in the mask, then use
            # it to compute the minimum enclosing circle and
            # centroid
            c = max(cnts, key=cv2.contourArea)
            ((x, y), radius) = cv2.minEnclosingCircle(c)
            M = cv2.moments(c)
            center = (int(M["m10"] / M["m00"]), int(M["m01"] / M["m00"]))
       
            # only proceed if the radius meets a minimum size. Correct this value for your obect's size
            if radius > 0.5:
                # draw the circle and centroid on the frame,
                # then update the list of tracked points
                #print('Tam vat mau',key,'la',int(x),'va',int(y))
                #cv2.circle(frame, (int(x), int(y)), int(radius), colors[key], 2)
                #cv2.circle(frame, (int(x), int(y)), int(2), colors[key], 2)
                #Draw central line of the item 
                cv2.line(frame,(int(x) + 10,int(y)),(int(x) - 10,int(y)),(255,255,0),1)
                cv2.line(frame,(int(x),int(y) +10),(int(x),int(y) -10),(255,255,0),1)
                cv2.putText(frame,key + "item", (int(x-radius),int(y-radius)), cv2.FONT_HERSHEY_SIMPLEX, 0.6,colors[key],1)
    #Draw central line of the frame 
    cv2.line(frame,(width/2,height/2-300),(width/2,height/2 + 300),(255,255,0),1)
    cv2.line(frame,(width/2-300,height/2),(width/2+300,height/2),(255,255,0),1)


    # show the frame to our screen
    cv2.imshow("Frame", frame)
    # if the esc key is pressed, stop the loop
    k = cv2.waitKey(5) & 0xFF
    if k == 27:
        break
# cleanup the camera and close any open windows
camera.release()
cv2.destroyAllWindows()
